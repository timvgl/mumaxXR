#Created by Tim Vogel
from mumaxXR.OvfEngine import OvfEngine, convert_TableFile_to_dataset