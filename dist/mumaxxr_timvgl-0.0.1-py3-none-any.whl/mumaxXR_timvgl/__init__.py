#Created by Tim Vogel
from mumaxXR.OvfEngine import OvfEngine